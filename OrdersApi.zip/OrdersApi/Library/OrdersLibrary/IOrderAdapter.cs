﻿using OrdersModels;
using System.Threading.Tasks;

namespace OrdersLibrary
{
    public interface IOrderAdapter
    {
        Task<OrderResponseModel> PostOrderRequestAsync(OrderRequestModel request);
        Task<OrderResponseModel> GetOrderTrackingStatusAsync(long orderId);
    }
}
