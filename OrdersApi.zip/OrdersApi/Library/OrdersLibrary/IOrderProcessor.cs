﻿using OrdersModels;
using System.Threading;
using System.Threading.Tasks;

namespace OrdersLibrary
{
    public interface IOrderProcessor
    {
        Task SubmitOrderRequest(OrderRequestModel request, CancellationToken cancellationToken);
    }
}
