﻿using Microsoft.Extensions.Logging;
using OrdersLibrary.PsuedoLegacyApi;
using System;
using System.Threading.Tasks;

namespace OrdersLibrary.LegacyApi
{
    internal class ApiOneClient : IApiOneClient
    {
        private readonly ILogger _logger;
        private readonly IApiOneServiceClient _serviceClient;

        public ApiOneClient(ILogger<ApiOneClient> logger, IApiOneServiceClient serviceClient)
        {
            _serviceClient = serviceClient;
            _logger = logger;
        }

        public async Task<OrderProcessingResponse> SendOrderRequestAsync(OrderPorcessingRequestModel request)
        {
            _logger.LogInformation($"ApiTwo Order process request started...");

            var results = await _serviceClient.PostOrderRequestAsync(request);

            if (!results.IsSuccessful)
            {
                _logger.LogInformation($"ApiTwo Order process request returned an error.");

                return new OrderProcessingResponse
                {
                    ErrorMessage = results.ErrorMessage,
                    IsSuccessful = false,
                    ProcessDate = results.ProcessDate
                };
            };

            _logger.LogInformation($"ApiTwo Order process request completed");
            return results;
        }
    }
}
