﻿using OrdersLibrary.PsuedoLegacyApi;
using OrdersModels;
using System.Threading.Tasks;

namespace OrdersLibrary.LegacyApi
{
    public interface IApiOneClient
    {
        Task<OrderProcessingResponse> SendOrderRequestAsync(OrderPorcessingRequestModel request);
    }
}