﻿using OrdersLibrary.PsuedoLegacyApi;
using System.Threading.Tasks;

namespace OrdersLibrary.LegacyApi
{
    public interface IApiTwoClient
    {
        Task<OrderProcessingResponse> SendOrderRequestAsync(OrderPorcessingRequestModel request);
    }
}
