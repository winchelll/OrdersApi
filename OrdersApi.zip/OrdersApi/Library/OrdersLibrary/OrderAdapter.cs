﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using OrdersLibrary.Queues;
using OrdersLibrary.Repository;
using OrdersModels;
using OrdersModels.Enums;
using System;
using System.Threading.Tasks;

namespace OrdersLibrary
{
    public class OrderAdapter : IOrderAdapter
    {
        private readonly ILogger _logger;
        private readonly IDatabaseClient _repository;
        private readonly IConfiguration _configuration;
        private readonly int _cohesionTimeout;
        private readonly int _dbTimeout;

        private readonly IOrdersQueue<OrderRequestModel> _queue;

        public OrderAdapter(IOrdersQueue<OrderRequestModel> queue, IDatabaseClient repository, IConfiguration configuration, ILogger<OrderAdapter> logger)
        {
            _queue = queue;
            _logger = logger;
            _repository = repository;
            _configuration = configuration;
            _cohesionTimeout = int.Parse(_configuration.GetSection("TimeOuts:CohesionTimeout").Value);
            _dbTimeout = int.Parse(_configuration.GetSection("TimeOuts:MisDBTimeOut").Value);
        }

        public async Task<OrderResponseModel> GetOrderTrackingStatusAsync(long orderId)
        {
            _logger.LogInformation($"OneTimeTransferAdapter: GetTransferTrackingStatusAsync started...");

            try
            {
                _logger.LogInformation($"OneTimeTransferAdapter: getting transfer history status.");

                // submit order request to the host
                var sqlResult = await _repository.GetOrderTrackingStatusAsync(orderId);

                // map sql result to response
                var response = sqlResult.ToMessage(orderId);


                _logger.LogInformation($"OneTimeTransferAdapter: GetTransferTrackingStatusAsync: completed.");
                return response;
            }
            catch (Exception ex)
            {
                var errorMessage = $"OneTimeTransferAdapter: Error getting transfer history status. Exception: {ex.Message}";
                _logger.LogError(errorMessage);
                return new OrderResponseModel
                {                   
                    TrackingStatus = (byte)TrackingStatus.Received,
                    OrderId = orderId,
                    ErrorMessage = errorMessage
                };
            }
        }

        public async Task<OrderResponseModel> PostOrderRequestAsync(OrderRequestModel request)
        {
            try
            {
                _logger.LogInformation($"OrderAdapter: OrderRequestAsync started...");
              
                // insert transfer tracking
                var insertSqlResult = await _repository.InsertOrderTrackingRequestAsync(request.OrderId, request);

                if (insertSqlResult == null) throw new ArgumentNullException("OrderAdapter: insertSqlResult", "Insert sql result cannot be null");
                if (insertSqlResult.ReturnCode == -1) throw new ArgumentException("OrderAdapter: Insert sql result returned -1 indicating an error occurred", "insertSqlResult.ReturnCode");

                if (insertSqlResult.ReturnCode == 0)
                {
                    // if here this externalTransferId has already been processed. To ensure idempotency, return current tracking status
                    switch (ConvertTrackingStatusToEnum(insertSqlResult.CurrentTrackingStatus))
                    {
                        case TrackingStatus.Success:
                            return new OrderResponseModel
                            {
                                IsSuccessful = true,
                                TrackingStatus = (byte)TrackingStatus.Received
                            };
                        case TrackingStatus.Error:
                            return new OrderResponseModel
                            {
                                IsSuccessful = false,
                                TrackingStatus = (byte)TrackingStatus.Received
                            };
                        case TrackingStatus.Failure:
                            return new OrderResponseModel
                            {
                                IsSuccessful = false,
                                TrackingStatus = (byte)TrackingStatus.Received
                            };
                        default:
                            return new OrderResponseModel
                            {
                                IsSuccessful = true,
                                TrackingStatus = (byte)TrackingStatus.Received
                            };
                    }
                }

                //queue order
                _logger.LogInformation($"OrderAdapter: Queueing order request for processing.");
                _queue.Enqueue(request);

                _logger.LogInformation($"OrderAdapter: OrderRequest: completed.");

                // return response
                return new OrderResponseModel
                {
                    IsSuccessful = true,
                    TrackingStatus = (byte)TrackingStatus.Received
                };
            }
            catch (Exception ex)
            {
                var errorMessage = $"OrderAdapter: Error performing order request. Exception: {ex.Message}";
                _logger.LogError(errorMessage);
                return new OrderResponseModel
                {                 
                    ErrorMessage = errorMessage,
                    IsSuccessful = false,
                    TrackingStatus = (byte)TrackingStatus.Received
                };
            }
        }

        private TrackingStatus ConvertTrackingStatusToEnum(byte trackingStatus)
        {
            // use to convert enum to byte passable to sqldbtype tinyint
            switch (trackingStatus)
            {
                case 1:
                    return TrackingStatus.Success;
                case 2:
                    return TrackingStatus.Error;
                case 3:
                    return TrackingStatus.Failure;
                default:
                    return TrackingStatus.Received;
            }
        }
    }
}
