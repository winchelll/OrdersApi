﻿using Microsoft.Extensions.Logging;
using OrdersLibrary.LegacyApi;
using OrdersLibrary.PsuedoLegacyApi;
using OrdersLibrary.Repository;
using OrdersModels;
using OrdersModels.Enums;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace OrdersLibrary
{
    public class OrderProcessor : IOrderProcessor
    {
        private readonly IApiOneClient _apiOneClient;
        private readonly IApiTwoClient _apiTwoClient;
        private readonly IDatabaseClient _repository;
        private readonly ILogger _logger;

        public OrderProcessor(IApiOneClient apiOneClient, IApiTwoClient apiTwoClient, IDatabaseClient repository, ILogger<OrderProcessor> logger)
        {
            _apiOneClient = apiOneClient;
            _apiTwoClient = apiTwoClient;
            _repository = repository;
            _logger = logger;
        }
        public async Task SubmitOrderRequest(OrderRequestModel request, CancellationToken cancellationToken)
        {
            try
            {
                _logger.LogInformation($"OrderProcessor: ProcessOneTimeTransferRequest started...");

                OrderResponseModel response = null;

                _logger.LogInformation($"OrderProcessor: Sending request to the host.");
                response = await SendRequest(request);

              
                //UPDATE DB
                _logger.LogInformation($"OrderProcessor: Updating transfer status.");
                await UpdateStatus(request.OrderId, response);

                _logger.LogInformation($"OrderProcessor: ProcessOneTimeTransferRequest: completed.");
            }
            catch (Exception ex)
            {
                var errorMessage = $"OrderProcessor: Error performing order request. Exception: {ex.Message}";
                _logger.LogError(errorMessage);
            }
        }

        private async Task<OrderResponseModel> SendRequest(OrderRequestModel request)
        {
            try
            {

                var response = new OrderResponseModel();
                _logger.LogInformation($"OrderProcessor: SendRequest started...");

                //Set up the call to back end APIs.
                var requestModel = new OrderPorcessingRequestModel
                {
                    OrderId = request.OrderId,
                    CustomerName = request.CustomerName,
                    ProductId = request.ProductId,
                    Address = request.Address,
                    City = request.City,
                    PostalCode = request.PostalCode,
                    Country = request.Country,
                    CountryCode = request.CountryCode,
                    OrderDate = request.OrderDate,
                    Phone = request.Phone,
                    Quantity = request.Quantity,
                    State = request.State
                };

                var apiOneResponse = await _apiOneClient.SendOrderRequestAsync(requestModel);

                await Task.Delay(5000);

                var requestTwoModel = new OrderPorcessingRequestTwoModel
                {
                    OrderId = request.OrderId,
                    ProductId = request.ProductId,
                    ProductName = request.ProductName,
                };
                var apiTwoResponse = await _apiTwoClient.SendOrderRequestAsync(requestModel);

                //map responses from legacy APIs to return to client
                if ((apiTwoResponse != null) || (apiOneResponse != null))
                {
                    response.OrderDate = request.OrderDate;
                    response.OrderId = request.OrderId;
                    response.Status = apiOneResponse.Status;
                    if (!string.IsNullOrEmpty(apiOneResponse.ErrorMessage) && !string.IsNullOrEmpty(apiTwoResponse.ErrorMessage))
                    {
                        response.ErrorMessage = $"(API ONE Error: {apiOneResponse.ErrorMessage} & API TWO Error: {apiTwoResponse.ErrorMessage})";
                    }
                    else if (!string.IsNullOrEmpty(apiOneResponse.ErrorMessage) && string.IsNullOrEmpty(apiTwoResponse.ErrorMessage))
                    {
                        response.ErrorMessage = $"(API ONE Error:{apiOneResponse.ErrorMessage})";
                    }
                    else
                    {
                        response.ErrorMessage = $"(API TWO Error:{apiOneResponse.ErrorMessage})";
                    }
                }
                
                _logger.LogInformation($"OrderProcessor: SendRequest: completed.");

                // return response
                return response;
            }
            catch (OperationCanceledException ex)
            {
                OrderResponseModel timedoutResponseMessage = new OrderResponseModel
                {
                    ErrorMessage = $"The process did not finish within the SLA: {ex.Message}",
                    TrackingStatus = (byte)TrackingStatus.Failure,
                    IsSuccessful = false,
                };
                _logger.LogError(timedoutResponseMessage.ErrorMessage);
                return timedoutResponseMessage;
            }
            catch (Exception ex)
            {
                var errorMessage = $"OrderProcessor: Error performing order request. Exception: {ex.Message}";
                _logger.LogError(errorMessage);
                return new OrderResponseModel
                {
                    ErrorMessage = errorMessage,
                    TrackingStatus = (byte)TrackingStatus.Failure,
                    IsSuccessful = false
                };
            }
        }

        //update db
        public async Task UpdateStatus(long orderId, OrderResponseModel response)
        {
            try
            {
                _logger.LogInformation($"OrderProcessor: UpdateStatus started...");

                // update transfer tracking
                var sqlRequest = new SqlOrderTrackingUpdateRequest
                {
                    OrderId = orderId,
                    Response = response,
                    ProcessDate = DateTime.Now
                };
                var updateSqlResult = await _repository.UpdateOrderTrackingRequestAsync(sqlRequest);

                if (updateSqlResult == null) throw new ArgumentNullException("OrderProcessor: updateSqlResult", "Update sql result cannot be null");
                if (updateSqlResult.ReturnCode == -1) throw new ArgumentException("OrderProcessor: Update sql result returned -1 but this should never occur", "insertSqlResult.ReturnCode");
                if (updateSqlResult.ReturnCode == 0) throw new ArgumentException("OrderProcessor: Update sql result returned 0 but this should never occur.", "insertSqlResult.ReturnCode");
            }
            catch (Exception ex)
            {
                // TODO gracefully handle an error during the update sproc but allow returning the response
                var errorMessage = $"OrderProcessor: Error while updating tracking status. Exception: {ex.Message}";
                _logger.LogError(errorMessage);
            }
            _logger.LogInformation($"OrderProcessor: UpdateStatus: completed.");
        }

        private TrackingStatus ConvertTrackingStatusToEnum(byte trackingStatus)
        {
            // use to convert enum to byte passable to sqldbtype tinyint
            switch (trackingStatus)
            {
                case 1:
                    return TrackingStatus.Success;
                case 2:
                    return TrackingStatus.Error;
                case 3:
                    return TrackingStatus.Failure;
                default:
                    return TrackingStatus.Received;
            }
        }
    }
}
