﻿using OrdersLibrary.Repository;
using OrdersModels;

namespace OrdersLibrary
{
    public static class OrderTrackingStatusExtensions
    {
        public static OrderResponseModel ToMessage(this SqlOrderTrackingStatusResponse result, long orderId)
        {
            var response = new OrderResponseModel();
            response.OrderId = orderId;
            response.Status = result.TrackingStatus;
            response.TrackingStatus = result.TrackingStatus;
            response.ErrorMessage = result.ErrorMessage;
            return response;
        }
    }
}
