﻿using System;
using System.Threading.Tasks;

namespace OrdersLibrary.PsuedoLegacyApi
{
    public class ApiOneServiceClient : IApiOneServiceClient
    {
        public Task<OrderProcessingResponse> PostOrderRequestAsync(OrderPorcessingRequestModel request)
        {
            throw new NotImplementedException();
        }
    }
}
