﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace OrdersLibrary.PsuedoLegacyApi
{
    public class ApiTwoServiceClient : IApiTwoServiceClient
    {
        public Task<OrderProcessingResponse> PostOrderRequestAsync(OrderPorcessingRequestModel request)
        {
            throw new NotImplementedException();
        }
    }
}
