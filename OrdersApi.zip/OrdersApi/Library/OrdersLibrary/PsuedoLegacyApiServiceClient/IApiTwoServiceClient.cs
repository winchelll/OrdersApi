﻿using System.Threading.Tasks;

namespace OrdersLibrary.PsuedoLegacyApi
{
    public interface IApiTwoServiceClient
    {
           Task<OrderProcessingResponse> PostOrderRequestAsync(OrderPorcessingRequestModel request);
    }
}
