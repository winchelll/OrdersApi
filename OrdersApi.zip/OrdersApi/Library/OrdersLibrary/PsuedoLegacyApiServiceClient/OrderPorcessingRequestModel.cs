﻿using System;

namespace OrdersLibrary.PsuedoLegacyApi
{
    public class OrderPorcessingRequestModel
    {
        public long OrderId { get; set; }
        public string ProductId { get; set; }
        public int Quantity { get; set; }
        public DateTime OrderDate { get; set; }
        public string CustomerName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string? State { get; set; }
        public string PostalCode { get; set; }
        public string Country { get; set; }
        public string Phone { get; set; }
        public int CountryCode { get; set; }
    }

    public class OrderPorcessingRequestTwoModel
    {
        public long OrderId { get; set; }
        public string ProductId { get; set; }
        public string ProductName { get; set; }
        public DateTime ProcessDate { get; set; }    
        public int Status { get; set; }
    }
}