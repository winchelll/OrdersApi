﻿using System;

namespace OrdersLibrary.PsuedoLegacyApi
{
    public class OrderProcessingResponse
    {
        public bool IsSuccessful { get; set; }
        public string ErrorMessage { get; set; }
        public byte Status { get; set; }
        public DateTime? ProcessDate { get; set; }

    }
}