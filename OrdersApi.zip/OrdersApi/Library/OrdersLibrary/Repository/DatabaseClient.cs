﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using OrdersModels;
using OrdersModels.Enums;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace OrdersLibrary.Repository
{
    public class DatabaseClient : IDatabaseClient
    {
        private readonly ILogger _logger;
        private readonly IConfiguration _configuration;
        private readonly string _connectionString;
        private readonly string _orderInsertTrackingSproc;
        private readonly string _orderUpdateTrackingSproc;
        private readonly string _orderGetStatusSproc;
        private int _dbTimeoutSeconds;

        public DatabaseClient(ILogger<DatabaseClient> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
            _connectionString = configuration.GetSection("ConnectionStrings:OrdersDbConnectionString").Value;
            _orderInsertTrackingSproc = _configuration.GetSection("StoredProcedure:OrderTrackingInsert").Value;
            _orderUpdateTrackingSproc = _configuration.GetSection("StoredProcedure:OrderTrackingUpdate").Value;
            _orderGetStatusSproc = _configuration.GetSection("StoredProcedure:OrderTrackingGetStatus").Value;
            _dbTimeoutSeconds = int.Parse(_configuration.GetSection("TimeOuts:DBTimeOut").Value);
        }

        public async Task<SqlOrderTrackingResponse> InsertOrderTrackingRequestAsync(long orderId, OrderRequestModel request)
        {
            try
            {
                SqlOrderTrackingResponse item = null;

                using SqlConnection connection = new SqlConnection(_connectionString);
                using SqlCommand command = new SqlCommand();
                command.CommandText = _orderInsertTrackingSproc;
                command.CommandType = CommandType.StoredProcedure;
                command.Connection = connection;
                command.Parameters.AddWithValue("@OrderId", orderId);
                command.Parameters.AddWithValue("@TrackingStatus", ConvertTrackingStatusToByte(TrackingStatus.Received));
                command.Parameters.AddWithValue("@RequestJSON", JsonConvert.SerializeObject(request));

                await connection.OpenAsync();
                StringBuilder jsonResult = new StringBuilder();
                SqlDataReader reader = null;

                //Set up a cancellation token.
                using CancellationTokenSource cts = new CancellationTokenSource();
                cts.CancelAfter(TimeSpan.FromSeconds(_dbTimeoutSeconds));
                cts.Token.ThrowIfCancellationRequested();

                //Defining the thread to publish to the database this way will throw OperationCancelledException if the token times out.
                Task t = Task.Run(async () => reader = await command.ExecuteReaderAsync());
                t.Wait(cts.Token);

                if (!reader.HasRows)
                {
                    jsonResult.Append("{}");
                }
                else
                {
                    while (await reader.ReadAsync())
                    {
                        jsonResult.Append(reader.GetValue(0).ToString());
                    }
                    item = JsonConvert.DeserializeObject<SqlOrderTrackingResponse>(jsonResult.ToString());
                }
                connection.Close();
                return item;
            }
            catch (OperationCanceledException ex)
            {
                _logger.LogError(ex.Message);
                return new SqlOrderTrackingResponse { ReturnCode = -1, ErrorMessage = ex.Message };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new SqlOrderTrackingResponse { ReturnCode = -1, ErrorMessage = ex.Message };
            }
        }

        public async Task<SqlOrderTrackingStatusResponse> GetOrderTrackingStatusAsync(long orderId)
        {
            // Reading SQL JSON Results into .NET Core
            // https://blog.bitscry.com/2020/06/22/reading-sql-json-results-into-net-core/
            try
            {
                SqlOrderTrackingStatusResponse item = null;
                using SqlConnection connection = new SqlConnection(_connectionString);
                using SqlCommand command = new SqlCommand();
                using CancellationTokenSource cts = new CancellationTokenSource();
                cts.CancelAfter(TimeSpan.FromSeconds(_dbTimeoutSeconds));
                cts.Token.ThrowIfCancellationRequested();
                command.CommandText = _orderGetStatusSproc;
                command.CommandType = CommandType.StoredProcedure;
                command.Connection = connection;
                command.Parameters.AddWithValue("@OrderId", orderId);


                await connection.OpenAsync();
                StringBuilder jsonResult = new StringBuilder();


                SqlDataReader reader = null;

                Task t = Task.Run(async () => reader = await command.ExecuteReaderAsync());
                t.Wait(cts.Token);

                if (!reader.HasRows)
                {
                    jsonResult.Append("{}");
                }
                else
                {
                    while (await reader.ReadAsync())
                    {
                        jsonResult.Append(reader.GetValue(0).ToString());
                    }
                    item = JsonConvert.DeserializeObject<SqlOrderTrackingStatusResponse>(jsonResult.ToString());
                }
                connection.Close();
                return item;
            }
            catch (Exception ex)
            {
                _logger.LogError("Error reading OrdersDb - member account supplemental", ex);
                return new SqlOrderTrackingStatusResponse
                {
                    ErrorMessage = "Error retrieving transfer tracking status from Transfer Tracking.",
                    TrackingStatus = (byte)TrackingStatus.Failure
                };
            }
        }

        public async Task<SqlOrderTrackingResponse> UpdateOrderTrackingRequestAsync(SqlOrderTrackingUpdateRequest request)
        {
            try
            {
                SqlOrderTrackingResponse item = null;

                using SqlConnection connection = new SqlConnection(_connectionString);
                using SqlCommand command = new SqlCommand();

                command.CommandText = _orderUpdateTrackingSproc;
                command.CommandType = CommandType.StoredProcedure;
                command.Connection = connection;
                command.Parameters.AddWithValue("@ExternalOrderID", request.OrderId);
                command.Parameters.AddWithValue("@TrackingStatus", request.Response.TrackingStatus);
                if (!string.IsNullOrEmpty(request.Response.ErrorMessage))
                {
                    command.Parameters.AddWithValue("@ErrorMessage", request.Response.ErrorMessage);
                }
                else
                {
                    command.Parameters.AddWithValue("@ErrorMessage", DBNull.Value);
                }
                command.Parameters.AddWithValue("@HostResponseJSON", JsonConvert.SerializeObject(request));
                command.Parameters.AddWithValue("@ProcessDate", request.ProcessDate);

                await connection.OpenAsync();
                StringBuilder jsonResult = new StringBuilder();
                SqlDataReader reader = null;

                //Set up a cancellation token.
                using CancellationTokenSource cts = new CancellationTokenSource();
                cts.CancelAfter(TimeSpan.FromSeconds(_dbTimeoutSeconds));
                cts.Token.ThrowIfCancellationRequested();

                //Defining the thread to publish to the database this way will throw OperationCancelledException if the token times out.
                Task t = Task.Run(async () => reader = await command.ExecuteReaderAsync());
                t.Wait(cts.Token);

                if (!reader.HasRows)
                {
                    jsonResult.Append("{}");
                }
                else
                {
                    while (await reader.ReadAsync())
                    {
                        jsonResult.Append(reader.GetValue(0).ToString());
                    }
                    item = JsonConvert.DeserializeObject<SqlOrderTrackingResponse>(jsonResult.ToString());
                }
                connection.Close();
                return item;
            }
            catch (OperationCanceledException ex)
            {
                _logger.LogError(ex.Message);
                return new SqlOrderTrackingResponse { ReturnCode = -1, ErrorMessage = ex.Message };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new SqlOrderTrackingResponse { ReturnCode = -1, ErrorMessage = ex.Message };
            }
        }

        private byte ConvertTrackingStatusToByte(TrackingStatus status)
        {
            // use to convert enum to byte passable to sqldbtype tinyint
            switch (status)
            {
                case TrackingStatus.Success:
                    return 1;
                case TrackingStatus.Error:
                    return 2;
                case TrackingStatus.Failure:
                    return 3;
                default:
                    return 0;
            }
        }



    }
}
