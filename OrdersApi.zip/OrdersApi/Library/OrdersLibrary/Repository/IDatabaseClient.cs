﻿using OrdersModels;
using System.Threading.Tasks;

namespace OrdersLibrary.Repository
{
    public interface IDatabaseClient
    {
        Task<SqlOrderTrackingResponse> InsertOrderTrackingRequestAsync(long externalTransferId, OrderRequestModel request);
        Task<SqlOrderTrackingResponse> UpdateOrderTrackingRequestAsync(SqlOrderTrackingUpdateRequest request);
        Task<SqlOrderTrackingStatusResponse> GetOrderTrackingStatusAsync(long externalTransferId);
    }
}
