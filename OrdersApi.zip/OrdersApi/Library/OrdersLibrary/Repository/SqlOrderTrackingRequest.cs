﻿using System;

namespace OrdersLibrary.Repository
{
    public class SqlOrderTrackingRequest
    {
        public long OrderId { get; set; }
        public string RequestJson { get; set; }
        public DateTime InsertDate { get; set; }
    }
}


