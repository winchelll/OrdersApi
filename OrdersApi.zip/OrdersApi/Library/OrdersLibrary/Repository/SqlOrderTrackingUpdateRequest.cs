﻿using OrdersModels;
using System;

namespace OrdersLibrary.Repository
{
    public class SqlOrderTrackingUpdateRequest
    {
        public long OrderId { get; set; }
        public OrderResponseModel Response { get; set; }
        public DateTime? ProcessDate { get; set; }
    }
}


