﻿using System;

namespace OrdersLibrary.Repository
{
    public class SqlTransferTrackingResponse
    {
        public Int16 ReturnCode { get; set; }

        public byte CurrentTrackingStatus { get; set; }

        public string ErrorMessage { get; set; }
    }
}
