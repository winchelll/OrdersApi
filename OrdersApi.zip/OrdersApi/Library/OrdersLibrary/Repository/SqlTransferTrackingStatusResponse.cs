﻿using System;

namespace OrdersLibrary.Repository
{
    public class SqlTransferTrackingStatusResponse
    {
        public byte TrackingStatus { get; set; }
        public DateTime? InsertDateTime { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public string ErrorMessage { get; set; }
    }
}
