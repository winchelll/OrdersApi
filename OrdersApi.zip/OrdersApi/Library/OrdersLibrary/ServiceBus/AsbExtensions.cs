﻿using Azure.Messaging.ServiceBus;
using OrdersModels;
using System;
using System.Collections.Generic;

namespace OrdersLibrary.ServiceBus
{
    internal static class AsbExtensions
    {
        public static IEnumerable<ServiceBusMessage> ToServiceBusMessageIEnumerable(this OrderRequestModel request)
        {
            var body = BinaryData.FromObjectAsJson(request);
            var message = new ServiceBusMessage(body);

            //assign OrderId as service bus MessageId to prevent duplication
            //the service bus queue must have duplicate detection enabled
            message.MessageId = request.OrderId.ToString();
            IEnumerable<ServiceBusMessage> list = new[] { message };
            return list;
        }
    }
}
