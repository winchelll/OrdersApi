﻿using Azure.Messaging.ServiceBus;
using Microsoft.Extensions.Azure;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using OrdersModels;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace OrdersLibrary.ServiceBus
{
    public class AsbOrdersWorker : BackgroundService
    {
        private readonly IAzureClientFactory<ServiceBusClient> _serviceBusClientFactory;
        private readonly IServiceScopeFactory _scopeFactory;
        private readonly ILogger<AsbOrdersWorker> _logger;

        private ServiceBusClient _client;
        private ServiceBusProcessor _processor;
        private int _maxConcurrentCalls = 2;
        private readonly string _queueName;

        public AsbOrdersWorker(IAzureClientFactory<ServiceBusClient> serviceBusClientFactory, IServiceScopeFactory scopeFactory,
            IConfiguration configuration, ILogger<AsbOrdersWorker> logger)
        {
            _serviceBusClientFactory = serviceBusClientFactory;
            _queueName = configuration.GetSection("ServiceBus:QueueName").Value;
            int.TryParse(configuration.GetSection("ServiceBus:MaxConcurrentCalls").Value, out _maxConcurrentCalls);
            _scopeFactory = scopeFactory;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                _logger.LogInformation("INFO: {0} is starting...", nameof(AsbOrdersWorker));

                // Create the client object that will be used to create receiver objects
                _client = _serviceBusClientFactory.CreateClient("service-bus-client");

                // create the options to use for configuring the processor
                var options = new ServiceBusProcessorOptions
                {
                    // By default or when AutoCompleteMessages is set to true, the processor will complete the message after executing the message handler
                    // Set AutoCompleteMessages to false to [settle messages](https://docs.microsoft.com/en-us/azure/service-bus-messaging/message-transfers-locks-settlement#peeklock) on your own.
                    // In both cases, if the message handler throws an exception without settling the message, the processor will abandon the message.
                    AutoCompleteMessages = false,

                    // I can also allow for multi-threadingy
                    MaxConcurrentCalls = _maxConcurrentCalls
                };

                // create a processor that we can use to process the messages
                _processor = _client.CreateProcessor(_queueName, options);

                _logger.LogInformation("INFO: {0} - {1} MaxConcurrentCalls set to: {2}.", nameof(AsbOrdersWorker), nameof(ServiceBusProcessor), _maxConcurrentCalls);

                // add handler to process messages
                _processor.ProcessMessageAsync += _processor_ProcessMessageAsync;

                // add handler to process any errors
                _processor.ProcessErrorAsync += _processor_ProcessErrorAsync;

                // start processing 
                await _processor.StartProcessingAsync(stoppingToken);

                _logger.LogInformation("INFO: {0} - {1} is now running...", nameof(AsbOrdersWorker), nameof(ServiceBusProcessor));
            }
            catch (Exception ex)
            {
                _logger.LogError("ERROR: {0} Exception: {1}", nameof(AsbOrdersWorker), ex.ToString());
            }

            //await BackgroundProcessing(stoppingToken);
        }

        private async Task _processor_ProcessMessageAsync(ProcessMessageEventArgs args)
        {
            try
            {
                _logger.LogInformation("INFO: {0} Received MsgId: {1} SeqNo: {2} CorrId: {3}", nameof(AsbOrdersWorker), args.Message?.MessageId, args.Message?.SequenceNumber, args.Message?.CorrelationId);

                using var scope = _scopeFactory.CreateScope();

                //deserialize message 
                var request = JsonConvert.DeserializeObject<OrderRequestModel>(args.Message.Body.ToString());

                //get transfer processor  
                var transferProcessor = scope.ServiceProvider.GetRequiredService<IOrderProcessor>();
                await transferProcessor.SubmitOrderRequest(request, args.CancellationToken);

                // complete the message. messages is deleted from the queue. 
                await args.CompleteMessageAsync(args.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError("ERROR: {0} - {1} Exception: {2}", nameof(AsbOrdersWorker), nameof(ServiceBusProcessor), ex.ToString());
            }
        }

        private Task _processor_ProcessErrorAsync(ProcessErrorEventArgs args)
        {
            _logger.LogError("ERROR: {0} Exception: {1}", nameof(AsbOrdersWorker), args.Exception?.ToString());
            return Task.CompletedTask;
        }

        public override Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogWarning("WARN: {0} is stopping due to a host shutdown, queued items may not be processed anymore.", nameof(AsbOrdersWorker));
            return base.StopAsync(cancellationToken);
        }
    }
}
