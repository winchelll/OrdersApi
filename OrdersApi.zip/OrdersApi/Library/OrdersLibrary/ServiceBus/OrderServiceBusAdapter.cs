﻿using Azure.Messaging.ServiceBus;
using Microsoft.Extensions.Azure;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using OrdersLibrary.Repository;
using OrdersModels;
using OrdersModels.Enums;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OrdersLibrary.ServiceBus
{
    public class OrderServiceBusAdapter : IOrderAdapter
    {
        private readonly IAzureClientFactory<ServiceBusClient> _serviceBusClientFactory;
        private ServiceBusClient _client;
        private ServiceBusSender _sender;
        private readonly IDatabaseClient _repository;
        private readonly ILogger _logger;
        private readonly string _queueName;

        public OrderServiceBusAdapter(IAzureClientFactory<ServiceBusClient> serviceBusClientFactory, IDatabaseClient repository, IConfiguration configuration, ILogger<OrderServiceBusAdapter> logger)
        {
            _serviceBusClientFactory = serviceBusClientFactory;
            _repository = repository;
            _logger = logger;

            //read queue name from configuration
            _queueName = configuration.GetSection("OrdersLibrary:ServiceBus:QueueName").Value;

            //get service bus client using the factory
            _client = _serviceBusClientFactory.CreateClient("service-bus-client");

            // use the client to create sender
            _sender = _client.CreateSender(_queueName);
        }

        public async Task<OrderResponseModel> GetOrderTrackingStatusAsync(long orderId)
        {
            OrderResponseModel response = null;
            try
            {
                _logger.LogInformation("INFO: {0} getting transfer tracking status...", nameof(OrderServiceBusAdapter));
               

                // submit order request to the host
                var sqlResult = await _repository.GetOrderTrackingStatusAsync(orderId);

                // map sql result to response
                response = sqlResult.ToMessage(orderId);

                _logger.LogInformation("INFO: {0} get transfer tracking status completed.", nameof(OrderServiceBusAdapter));
                return response;
            }
            catch (Exception ex)
            {
                var errorMessage = $"Error getting transfer history status. Exception: {ex.Message}";
                _logger.LogError(ex, "ERROR: {0} - {1}", nameof(OrderServiceBusAdapter), errorMessage);
                return new OrderResponseModel
                {
                    Status = (byte)TrackingStatus.Failure,
                    TrackingStatus = (byte)TrackingStatus.Failure,
                    OrderId = orderId,
                    ErrorMessage = errorMessage
                };
            }
        }

        public async Task<OrderResponseModel> PostOrderRequestAsync(OrderRequestModel request)
        {
            try
            {
                _logger.LogInformation("INFO: {0} one time transfer starting...", nameof(OrderServiceBusAdapter));

              
                // insert transfer tracking
                //var insertSqlResult = await _repository.InsertOrderTrackingRequestAsync(request.OrderId, request);

                //if (insertSqlResult == null) throw new ArgumentNullException("insertSqlResult", "Transfer Tracking Insert sql result cannot be null.");
                //if (insertSqlResult.ReturnCode == -1) throw new ArgumentException("Transfer Tracking Insert sql result returned -1 indicating an error occurred.", "insertSqlResult.ReturnCode");

                //if (insertSqlResult.ReturnCode == 0)
                //{
                //    // if here this externalTransferId has already been processed. To ensure idempotency, return current tracking status
                //    switch (ConvertTrackingStatusToEnum(insertSqlResult.CurrentTrackingStatus))
                //    {
                //        case TrackingStatus.Success:
                //            return new OrderResponseModel
                //            {
                //                IsSuccessful = true,
                //                TrackingStatus = (byte)TrackingStatus.Success
                //            };
                //        case TrackingStatus.Error:
                //            return new OrderResponseModel
                //            {
                //                IsSuccessful = false,
                //                TrackingStatus = (byte)TrackingStatus.Error
                //            };
                //        case TrackingStatus.Failure:
                //            return new OrderResponseModel
                //            {
                //                IsSuccessful = false,
                //                TrackingStatus = (byte)TrackingStatus.Failure
                //            };
                //        default:
                //            return new OrderResponseModel
                //            {
                //                IsSuccessful = false,
                //                TrackingStatus = (byte)TrackingStatus.Received
                //            };
                //    }
                //}

                //queue one time transfer
                _logger.LogInformation("INFO: {0} queueing order request for processing.", nameof(OrderServiceBusAdapter));

                IEnumerable<ServiceBusMessage> messages = null;
                try
                {
                    //prepare service bus message
                    messages = request.ToServiceBusMessageIEnumerable();
                }
                catch (Exception ex)
                {
                    var errorMessage = $"Unable to prepare service bus message from the request. Exception: {ex.Message}";
                    _logger.LogError(ex, "ERROR: {0} - {1}", nameof(OrderServiceBusAdapter), errorMessage);

                    return new OrderResponseModel
                    {                     
                        ErrorMessage = errorMessage,
                        IsSuccessful = false,
                        TrackingStatus = (byte)TrackingStatus.Failure                      
                    };
                }

                try
                {
                    //send the request to the Service Bus queue
                    await _sender.SendMessagesAsync(messages);
                }
                catch (Exception ex)
                {
                    var errorMessage = $"Unable to send the service bus message (request) to the queue. Exception: {ex.Message}";
                    _logger.LogError(ex, "ERROR: {0} - {1}", nameof(OrderServiceBusAdapter), errorMessage);

                    return new OrderResponseModel
                    {
                        ErrorMessage = errorMessage,
                        IsSuccessful = false,
                        TrackingStatus = (byte)TrackingStatus.Failure
                    };
                }

                // return response
                _logger.LogInformation("INFO: {0} order request queued successfully.", nameof(OrderServiceBusAdapter));
                return new OrderResponseModel
                {
                    IsSuccessful = true,
                    TrackingStatus = (byte)TrackingStatus.Received
                };
            }
            catch (Exception ex)
            {
                var errorMessage = $"Error processing order request. Exception: {ex.Message}";
                _logger.LogError(ex, "ERROR: {0} - {1}", nameof(OrderServiceBusAdapter), errorMessage);

                return new OrderResponseModel
                {
                    ErrorMessage = errorMessage,
                    IsSuccessful = false,
                    TrackingStatus = (byte)TrackingStatus.Failure
                };
            }
        }

        private TrackingStatus ConvertTrackingStatusToEnum(byte trackingStatus)
        {
            // use to convert enum to byte passable to sqldbtype tinyint
            switch (trackingStatus)
            {
                case 1:
                    return TrackingStatus.Success;
                case 2:
                    return TrackingStatus.Error;
                case 3:
                    return TrackingStatus.Failure;
                default:
                    return TrackingStatus.Received;
            }
        }
    }
}
