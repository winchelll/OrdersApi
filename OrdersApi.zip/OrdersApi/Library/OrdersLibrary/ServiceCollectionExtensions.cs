﻿using Microsoft.Extensions.Azure;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using OrdersLibrary.LegacyApi;
using OrdersLibrary.PsuedoLegacyApi;
using OrdersLibrary.Repository;
using OrdersLibrary.ServiceBus;
using System;

namespace OrdersLibrary
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddOrdersLibrary(this IServiceCollection services, IConfiguration configuration)
        {
            //add psuedo clients
            services.AddTransient<IApiOneServiceClient, ApiOneServiceClient>();
            services.AddTransient<IApiTwoServiceClient, ApiTwoServiceClient>();

            // add clients
            services.AddTransient<IApiOneClient, ApiOneClient>();
            services.AddTransient<IApiTwoClient, ApiTwoClient>();

            //add DB client
            services.AddTransient<IDatabaseClient, DatabaseClient>();


            var asbConnectionString = configuration.GetSection("OrdersLibrary:ServiceBus:ConnectionString").Value;
            var asbQueueName = configuration.GetSection("OrdersLibrary:ServiceBus:QueueName").Value;

            services.AddAzureClients(clientsBuilder =>
            {
                clientsBuilder.AddServiceBusClient(asbConnectionString)
                  // (Optional) Provide name for instance to retrieve by with DI
                  .WithName("service-bus-client")
                  // (Optional) Override ServiceBusClientOptions (e.g. change retry settings)
                  .ConfigureOptions(options =>
                  {
                      options.RetryOptions.Delay = TimeSpan.FromMilliseconds(50);
                      options.RetryOptions.MaxDelay = TimeSpan.FromSeconds(5);
                      options.RetryOptions.MaxRetries = 3;
                  });
            });

            services.AddTransient<IOrderAdapter, OrderServiceBusAdapter>();
            services.AddScoped<IOrderProcessor, OrderProcessor>();
       

            return services;
        }

   

    
    }

}
