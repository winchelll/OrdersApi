﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OrdersModels.Enums
{
    public enum TrackingStatus
    {
        Received = 0,
        Success = 1,     
        Error = 2,
        Failure = 3
    }
}
