﻿using System;

namespace OrdersModels
{
    public class OrderRequestModel
    {
        public long OrderId { get; set; }
        public string ProductId { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public DateTime OrderDate { get; set; }
        public string CustomerName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string? State { get; set; }
        public string PostalCode { get; set; }
        public string Country { get; set; }
        public string Phone { get; set; }
        public int CountryCode { get; set; }
        public int TrackingStatus { get; set; } //0=Recevied, 1=In Process, 2=Shpped, 3=Delivered, 4=Cancelled
    }
}
