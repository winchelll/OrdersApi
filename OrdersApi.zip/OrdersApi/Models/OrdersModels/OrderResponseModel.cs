﻿using OrdersModels.Enums;
using System;

namespace OrdersModels
{
    public class OrderResponseModel
    {
        public long OrderId { get; set; }
        public string ProductId { get; set; }
        public string ProductName { get; set; }
        public int Quantoty { get; set; }
        public DateTime OrderDate { get; set; }
        public DateTime? ShipDate { get; set; }
        public DateTime? DeliverDate { get; set; }
        public DateTime? CancelDate { get; set; }
        public byte TrackingStatus { get; set; }
        public bool IsSuccessful { get; set; }
        public string ErrorMessage { get; set; }
        public byte Status { get; set; } //0=Recevied, 1=In Process, 2=Shpped, 3=Delivered, 4=Cancelled
    }
}
