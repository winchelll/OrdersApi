﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using OrdersLibrary;
using OrdersModels;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace OrdersApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly IOrderAdapter _orderAdapter;
        private readonly ILogger _logger;
        public OrdersController(IOrderAdapter orderAdapter, ILogger logger)
        {
            _orderAdapter = orderAdapter;
            _logger = logger;
        }
       

        // GET api/<OrdersController>/5
        [HttpGet("GetStatus/{orderId}")]
        public async Task<OrderResponseModel> GetOrderStatus(long orderId)
        {
            try
            {
                return await _orderAdapter.GetOrderTrackingStatusAsync(orderId);
            }
            catch (System.Exception ex)
            {

                _logger.LogError(ex.Message.ToString());
                return new OrderResponseModel
                {
                    IsSuccessful = false,
                    ErrorMessage = ex.Message
                };
            }
          
        }

        // POST api/<OrdersController>
        [HttpPost("PostRequest")]
        public async Task<OrderResponseModel> PostOrderRequest([FromBody] OrderRequestModel request)
        {
            try
            {
                return await _orderAdapter.PostOrderRequestAsync(request);
            }
            catch (System.Exception ex)
            {

                _logger.LogError(ex.Message.ToString());
                return new OrderResponseModel
                {
                    IsSuccessful = false,
                    ErrorMessage = ex.Message
                };
            }
           
        }
    }
}
